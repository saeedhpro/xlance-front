export { default as Rating } from '../..\\components\\global\\rating.vue'
export { default as Dropzone } from '../..\\components\\Dropzone.vue'
export { default as ImageUpload } from '../..\\components\\imageUpload.vue'
export { default as Loading } from '../..\\components\\Loading.vue'
export { default as Logo } from '../..\\components\\Logo.vue'
export { default as Notification } from '../..\\components\\Notification.vue'
export { default as RatingComponent } from '../..\\components\\RatingComponent.vue'
export { default as StorySocial } from '../..\\components\\StorySocial.vue'
export { default as StorySSS } from '../..\\components\\StorySSS.vue'
export { default as VuetifyLogo } from '../..\\components\\VuetifyLogo.vue'
export { default as AdminFilterUsers } from '../..\\components\\admin\\FilterUsers.vue'
export { default as AdminFooterAdmin } from '../..\\components\\admin\\FooterAdmin.vue'
export { default as AdminFormAdmin } from '../..\\components\\admin\\FormAdmin.vue'
export { default as AdminHeaderAdmin } from '../..\\components\\admin\\HeaderAdmin.vue'
export { default as AdminNavbarAdmin } from '../..\\components\\admin\\NavbarAdmin.vue'
export { default as AdminTableAdmin } from '../..\\components\\admin\\TableAdmin.vue'
export { default as ChatMessage } from '../..\\components\\chat\\ChatMessage.vue'
export { default as ClientCallForAdvice } from '../..\\components\\client\\CallForAdvice.vue'
export { default as ClientFilters } from '../..\\components\\client\\Filters.vue'
export { default as ClientFooter } from '../..\\components\\client\\Footer.vue'
export { default as ClientHeader } from '../..\\components\\client\\Header.vue'
export { default as DashboardFooterDashboard } from '../..\\components\\dashboard\\FooterDashboard.vue'
export { default as DashboardHeaderDashboard } from '../..\\components\\dashboard\\HeaderDashboard.vue'
export { default as DashboardMyProject } from '../..\\components\\dashboard\\MyProject.vue'
export { default as DashboardMyProjectKarfarma } from '../..\\components\\dashboard\\MyProjectKarfarma.vue'
export { default as DashboardNavbar } from '../..\\components\\dashboard\\Navbar.vue'
export { default as DashboardSelect } from '../..\\components\\dashboard\\Select.vue'
export { default as DashboardSelectTypeProject } from '../..\\components\\dashboard\\SelectTypeProject.vue'
export { default as DashboardTab } from '../..\\components\\dashboard\\Tab.vue'
export { default as EmployerShowCv } from '../..\\components\\employer\\ShowCv.vue'
export { default as EmployerShowListProjects } from '../..\\components\\employer\\ShowListProjects.vue'
export { default as EmployerShowSelect } from '../..\\components\\employer\\ShowSelect.vue'
export { default as HelperEventBus } from '../..\\components\\helper\\EventBus.js'
export { default as ProjectFreelancertaeed } from '../..\\components\\project\\freelancertaeed.vue'
export { default as RegisterGlobal } from '../..\\components\\register\\Global.vue'
export { default as RegisterInputs } from '../..\\components\\register\\Inputs.vue'
export { default as RegisterPurpleButtonGlobal } from '../..\\components\\register\\PurpleButtonGlobal.vue'
export { default as RegisterPurpolButtonGlobalLink } from '../..\\components\\register\\PurpolButtonGlobalLink.vue'
export { default as RegisterWhiteButtonGlobal } from '../..\\components\\register\\WhiteButtonGlobal.vue'
export { default as RegisterWhiteButtonGlobalLink } from '../..\\components\\register\\WhiteButtonGlobalLink.vue'
export { default as AdminChartColumnChart } from '../..\\components\\admin\\chart\\ColumnChart.vue'
export { default as AdminChartDisputedChart } from '../..\\components\\admin\\chart\\DisputedChart.vue'
export { default as AdminChartLineCharts } from '../..\\components\\admin\\chart\\LineCharts.vue'
export { default as AdminChartProjectChart } from '../..\\components\\admin\\chart\\ProjectChart.vue'
export { default as ClientHomeAdvantages } from '../..\\components\\client\\home\\Advantages.vue'
export { default as ClientHomeBestFreelancer } from '../..\\components\\client\\home\\BestFreelancer.vue'
export { default as ClientHomeHead } from '../..\\components\\client\\home\\Head.vue'
export { default as ClientHomeNewProject } from '../..\\components\\client\\home\\NewProject.vue'
export { default as ClientHomeNews } from '../..\\components\\client\\home\\News.vue'
export { default as ClientHomeTopHome } from '../..\\components\\client\\home\\TopHome.vue'
export { default as ClientProjectsProjectRequest } from '../..\\components\\client\\projects\\ProjectRequest.vue'
export { default as ClientProjectsDescriptions } from '../..\\components\\client\\projects\\ProjectsDescriptions.vue'
export { default as DashboardAnnouncements } from '../..\\components\\dashboard\\announcements\\Announcements.vue'
export { default as DashboardDifferences } from '../..\\components\\dashboard\\differences\\Differences.vue'
export { default as DashboardEmployeSelectemploye } from '../..\\components\\dashboard\\employe\\Selectemploye.vue'
export { default as DashboardEmployeSocialNetworksEmployer } from '../..\\components\\dashboard\\employe\\SocialNetworksEmployer.vue'
export { default as DashboardEmployeSuggest } from '../..\\components\\dashboard\\employe\\Suggest.vue'
export { default as DashboardFreelancerListFleelancerFilter } from '../..\\components\\dashboard\\freelancerList\\FleelancerFilter.vue'
export { default as DashboardGlobalCreateProject } from '../..\\components\\dashboard\\global\\CreateProject.vue'
export { default as DashboardGlobalInf } from '../..\\components\\dashboard\\global\\Inf.vue'
export { default as DashboardGlobalInf2 } from '../..\\components\\dashboard\\global\\Inf2.vue'
export { default as DashboardGlobalInfGreen } from '../..\\components\\dashboard\\global\\InfGreen.vue'
export { default as DashboardGlobalListProject } from '../..\\components\\dashboard\\global\\ListProject.vue'
export { default as DashboardGlobalMultiSelect } from '../..\\components\\dashboard\\global\\MultiSelect.vue'
export { default as DashboardGlobalSearchInput } from '../..\\components\\dashboard\\global\\SearchInput.vue'
export { default as DashboardGlobalSelectInput } from '../..\\components\\dashboard\\global\\SelectInput.vue'
export { default as DashboardGlobalTabSelect } from '../..\\components\\dashboard\\global\\TabSelect.vue'
export { default as DashboardProfileAccountProfile } from '../..\\components\\dashboard\\Profile\\AccountProfile.vue'
export { default as DashboardProfileAutoCompletes } from '../..\\components\\dashboard\\Profile\\AutoCompletes.vue'
export { default as DashboardProfileCv } from '../..\\components\\dashboard\\Profile\\Cv.vue'
export { default as DashboardProfileCvList } from '../..\\components\\dashboard\\Profile\\CvList.vue'
export { default as DashboardProfileDateInput } from '../..\\components\\dashboard\\Profile\\DateInput.vue'
export { default as DashboardProfilePassword } from '../..\\components\\dashboard\\Profile\\Password.vue'
export { default as DashboardProfilePicture } from '../..\\components\\dashboard\\Profile\\Picture.vue'
export { default as DashboardProfilePortfolios } from '../..\\components\\dashboard\\Profile\\Portfolios.vue'
export { default as DashboardProfileShowCv } from '../..\\components\\dashboard\\Profile\\ShowCv.vue'
export { default as DashboardProfileShowPortfolios } from '../..\\components\\dashboard\\Profile\\ShowPortfolios.vue'
export { default as DashboardProfileShowSelect } from '../..\\components\\dashboard\\Profile\\ShowSelect.vue'
export { default as DashboardProfileSkills } from '../..\\components\\dashboard\\Profile\\Skills.vue'
export { default as DashboardProfileTabProfile } from '../..\\components\\dashboard\\Profile\\TabProfile.vue'
export { default as DashboardProjectDescription } from '../..\\components\\dashboard\\projectDescription\\Description.vue'
export { default as DashboardProjectDescriptionDesk } from '../..\\components\\dashboard\\projectDescription\\Desk.vue'
export { default as DashboardProjectDescriptionSelectComponents } from '../..\\components\\dashboard\\projectDescription\\SelectComponents.vue'
export { default as DashboardProjectDescriptionForEmployerCountSuggest } from '../..\\components\\dashboard\\projectDescriptionForEmployer\\CountSuggest.vue'
export { default as DashboardProjectDescriptionForEmployerSelectComponentsEmployer } from '../..\\components\\dashboard\\projectDescriptionForEmployer\\SelectComponentsEmployer.vue'
export { default as DashboardSocialMediaInformationFollowers } from '../..\\components\\dashboard\\socialMedia\\InformationFollowers.vue'
export { default as DashboardSocialMediaPostFormat } from '../..\\components\\dashboard\\socialMedia\\PostFormat.vue'
export { default as DashboardSocialMedia } from '../..\\components\\dashboard\\socialMedia\\SocialMedia.vue'
export { default as DashboardSocialMediaStoris } from '../..\\components\\dashboard\\socialMedia\\Storis.vue'
export { default as DashboardSocialMediaStory } from '../..\\components\\dashboard\\socialMedia\\Story.vue'
export { default as DashboardUserPanelBackgroundPicture } from '../..\\components\\dashboard\\UserPanel\\BackgroundPicture.vue'
export { default as DashboardUserPanelFinancialDepartment } from '../..\\components\\dashboard\\UserPanel\\FinancialDepartment.vue'
export { default as DashboardUserPanelFinancialDepartmentKarfarma } from '../..\\components\\dashboard\\UserPanel\\FinancialDepartmentKarfarma.vue'
export { default as DashboardUserPanelKarfarma } from '../..\\components\\dashboard\\UserPanel\\Karfarma.vue'
export { default as DashboardUserPanelPortfolio } from '../..\\components\\dashboard\\UserPanel\\Portfolio.vue'
export { default as DashboardUserPanelProjects } from '../..\\components\\dashboard\\UserPanel\\Projects.vue'
export { default as DashboardUserPanelProjectsAndProposals } from '../..\\components\\dashboard\\UserPanel\\ProjectsAndProposals.vue'
export { default as DashboardUserPanelSelectPerson } from '../..\\components\\dashboard\\UserPanel\\SelectPerson.vue'
export { default as DashboardUserPanelSocialNetworks } from '../..\\components\\dashboard\\UserPanel\\SocialNetworks.vue'
export { default as DashboardUserPanel } from '../..\\components\\dashboard\\UserPanel\\UserPanel.vue'
export { default as DashboardWallAccountSettings } from '../..\\components\\dashboard\\wall\\AccountSettings.vue'
export { default as DashboardWallBardasht } from '../..\\components\\dashboard\\wall\\Bardasht.vue'
export { default as DashboardWallIncreaseInventory } from '../..\\components\\dashboard\\wall\\IncreaseInventory.vue'
export { default as DashboardWallPardakht } from '../..\\components\\dashboard\\wall\\Pardakht.vue'
export { default as DashboardWallRecords } from '../..\\components\\dashboard\\wall\\Records.vue'
export { default as DashboardWallTabBardasht } from '../..\\components\\dashboard\\wall\\TabBardasht.vue'
export { default as DashboardWallTabWallet } from '../..\\components\\dashboard\\wall\\TabWallet.vue'
export { default as DashboardWallWallet } from '../..\\components\\dashboard\\wall\\Wallet.vue'
export { default as DashboardGlobalInf2Purple } from '../..\\components\\dashboard\\global\\infKarfarma\\Inf2Purple.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
