import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5f0b8cab = () => interopDefault(import('..\\pages\\About-us.vue' /* webpackChunkName: "pages/About-us" */))
const _2b8182f2 = () => interopDefault(import('..\\pages\\account\\index.vue' /* webpackChunkName: "pages/account/index" */))
const _5ba7ece2 = () => interopDefault(import('..\\pages\\account-setting\\index.vue' /* webpackChunkName: "pages/account-setting/index" */))
const _1580cbf3 = () => interopDefault(import('..\\pages\\announcements\\index.vue' /* webpackChunkName: "pages/announcements/index" */))
const _725351d3 = () => interopDefault(import('..\\pages\\blog\\index.vue' /* webpackChunkName: "pages/blog/index" */))
const _c4dabf46 = () => interopDefault(import('..\\pages\\chat\\index.vue' /* webpackChunkName: "pages/chat/index" */))
const _03e40ba5 = () => interopDefault(import('..\\pages\\commercialLevel\\index.vue' /* webpackChunkName: "pages/commercialLevel/index" */))
const _65a7d110 = () => interopDefault(import('..\\pages\\Contact-us.vue' /* webpackChunkName: "pages/Contact-us" */))
const _21f50e3c = () => interopDefault(import('..\\pages\\createProject\\index.vue' /* webpackChunkName: "pages/createProject/index" */))
const _4b886f22 = () => interopDefault(import('..\\pages\\cv\\index.vue' /* webpackChunkName: "pages/cv/index" */))
const _21ebeaeb = () => interopDefault(import('..\\pages\\dashboard\\index.vue' /* webpackChunkName: "pages/dashboard/index" */))
const _73ef83b6 = () => interopDefault(import('..\\pages\\defferences\\index.vue' /* webpackChunkName: "pages/defferences/index" */))
const _5d13daea = () => interopDefault(import('..\\pages\\Followers\\index.vue' /* webpackChunkName: "pages/Followers/index" */))
const _366b9512 = () => interopDefault(import('..\\pages\\freelancer\\index.vue' /* webpackChunkName: "pages/freelancer/index" */))
const _21696436 = () => interopDefault(import('..\\pages\\harvest\\index.vue' /* webpackChunkName: "pages/harvest/index" */))
const _3c794785 = () => interopDefault(import('..\\pages\\increaseInventory\\index.vue' /* webpackChunkName: "pages/increaseInventory/index" */))
const _2a81f9bd = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _2b626310 = () => interopDefault(import('..\\pages\\Membership-upgrade\\index.vue' /* webpackChunkName: "pages/Membership-upgrade/index" */))
const _0fba572e = () => interopDefault(import('..\\pages\\messages\\index.vue' /* webpackChunkName: "pages/messages/index" */))
const _dd6ca7dc = () => interopDefault(import('..\\pages\\myProject\\index.vue' /* webpackChunkName: "pages/myProject/index" */))
const _803af88c = () => interopDefault(import('..\\pages\\password\\index.vue' /* webpackChunkName: "pages/password/index" */))
const _c81518fe = () => interopDefault(import('..\\pages\\picture\\index.vue' /* webpackChunkName: "pages/picture/index" */))
const _55fd996a = () => interopDefault(import('..\\pages\\portfolios\\index.vue' /* webpackChunkName: "pages/portfolios/index" */))
const _01123ecc = () => interopDefault(import('..\\pages\\posts\\index.vue' /* webpackChunkName: "pages/posts/index" */))
const _0566147b = () => interopDefault(import('..\\pages\\projects\\index.vue' /* webpackChunkName: "pages/projects/index" */))
const _47c80086 = () => interopDefault(import('..\\pages\\records\\index.vue' /* webpackChunkName: "pages/records/index" */))
const _12cc6ffa = () => interopDefault(import('..\\pages\\Rules.vue' /* webpackChunkName: "pages/Rules" */))
const _d1b2d31a = () => interopDefault(import('..\\pages\\skills\\index.vue' /* webpackChunkName: "pages/skills/index" */))
const _b6913830 = () => interopDefault(import('..\\pages\\socialMedia\\index.vue' /* webpackChunkName: "pages/socialMedia/index" */))
const _0e7d0de8 = () => interopDefault(import('..\\pages\\stories\\index.vue' /* webpackChunkName: "pages/stories/index" */))
const _cc6bcb48 = () => interopDefault(import('..\\pages\\wallet\\index.vue' /* webpackChunkName: "pages/wallet/index" */))
const _7f584758 = () => interopDefault(import('..\\pages\\admin\\Announcements\\index.vue' /* webpackChunkName: "pages/admin/Announcements/index" */))
const _b551f8a4 = () => interopDefault(import('..\\pages\\admin\\Article\\index.vue' /* webpackChunkName: "pages/admin/Article/index" */))
const _4be04f65 = () => interopDefault(import('..\\pages\\admin\\City\\index.vue' /* webpackChunkName: "pages/admin/City/index" */))
const _ecc140dc = () => interopDefault(import('..\\pages\\admin\\dashboard.vue' /* webpackChunkName: "pages/admin/dashboard" */))
const _3d31d1be = () => interopDefault(import('..\\pages\\admin\\Disputes\\index.vue' /* webpackChunkName: "pages/admin/Disputes/index" */))
const _5119f8de = () => interopDefault(import('..\\pages\\admin\\MemberShipUpgrade\\index.vue' /* webpackChunkName: "pages/admin/MemberShipUpgrade/index" */))
const _0f7a2806 = () => interopDefault(import('..\\pages\\admin\\Message\\index.vue' /* webpackChunkName: "pages/admin/Message/index" */))
const _621e9240 = () => interopDefault(import('..\\pages\\admin\\NotificationAdmin\\index.vue' /* webpackChunkName: "pages/admin/NotificationAdmin/index" */))
const _7364b0cf = () => interopDefault(import('..\\pages\\admin\\ProjectsAdmin\\index.vue' /* webpackChunkName: "pages/admin/ProjectsAdmin/index" */))
const _b0e32c4a = () => interopDefault(import('..\\pages\\admin\\property\\index.vue' /* webpackChunkName: "pages/admin/property/index" */))
const _3485995c = () => interopDefault(import('..\\pages\\admin\\PropertySendRequest\\index.vue' /* webpackChunkName: "pages/admin/PropertySendRequest/index" */))
const _230daa3c = () => interopDefault(import('..\\pages\\admin\\Records\\index.vue' /* webpackChunkName: "pages/admin/Records/index" */))
const _544d1cce = () => interopDefault(import('..\\pages\\admin\\ShowRequestWallet\\index.vue' /* webpackChunkName: "pages/admin/ShowRequestWallet/index" */))
const _54003f17 = () => interopDefault(import('..\\pages\\admin\\SkillsAdmin\\index.vue' /* webpackChunkName: "pages/admin/SkillsAdmin/index" */))
const _675ab6ae = () => interopDefault(import('..\\pages\\admin\\UsersAdmin\\index.vue' /* webpackChunkName: "pages/admin/UsersAdmin/index" */))
const _7df77f30 = () => interopDefault(import('..\\pages\\auth\\Complete-registration.vue' /* webpackChunkName: "pages/auth/Complete-registration" */))
const _be8f763c = () => interopDefault(import('..\\pages\\auth\\Forget.vue' /* webpackChunkName: "pages/auth/Forget" */))
const _23cd327a = () => interopDefault(import('..\\pages\\auth\\Log-in.vue' /* webpackChunkName: "pages/auth/Log-in" */))
const _d759f950 = () => interopDefault(import('..\\pages\\auth\\Register.vue' /* webpackChunkName: "pages/auth/Register" */))
const _08def460 = () => interopDefault(import('..\\pages\\dashboard\\Wallet.vue' /* webpackChunkName: "pages/dashboard/Wallet" */))
const _745b7151 = () => interopDefault(import('..\\pages\\freelancer\\ListFreelancer.vue' /* webpackChunkName: "pages/freelancer/ListFreelancer" */))
const _0a451318 = () => interopDefault(import('..\\pages\\password\\Change.vue' /* webpackChunkName: "pages/password/Change" */))
const _48e9e572 = () => interopDefault(import('..\\pages\\posts\\create.vue' /* webpackChunkName: "pages/posts/create" */))
const _3fe470e2 = () => interopDefault(import('..\\pages\\posts\\myPost.vue' /* webpackChunkName: "pages/posts/myPost" */))
const _7dba3cf3 = () => interopDefault(import('..\\pages\\posts\\save.vue' /* webpackChunkName: "pages/posts/save" */))
const _4721f332 = () => interopDefault(import('..\\pages\\stories\\create.vue' /* webpackChunkName: "pages/stories/create" */))
const _4941061c = () => interopDefault(import('..\\pages\\admin\\Article\\Category.vue' /* webpackChunkName: "pages/admin/Article/Category" */))
const _2d3dbcd0 = () => interopDefault(import('..\\pages\\admin\\Article\\create.vue' /* webpackChunkName: "pages/admin/Article/create" */))
const _cca4fab8 = () => interopDefault(import('..\\pages\\admin\\SkillsAdmin\\AddCategory.vue' /* webpackChunkName: "pages/admin/SkillsAdmin/AddCategory" */))
const _53bbee87 = () => interopDefault(import('..\\pages\\admin\\SkillsAdmin\\create.vue' /* webpackChunkName: "pages/admin/SkillsAdmin/create" */))
const _6d4cb2f1 = () => interopDefault(import('..\\pages\\admin\\SoclialMediaAdmin\\CreateStory.vue' /* webpackChunkName: "pages/admin/SoclialMediaAdmin/CreateStory" */))
const _42433c8b = () => interopDefault(import('..\\pages\\admin\\SoclialMediaAdmin\\posts.vue' /* webpackChunkName: "pages/admin/SoclialMediaAdmin/posts" */))
const _685f62be = () => interopDefault(import('..\\pages\\admin\\SoclialMediaAdmin\\StoreisList.vue' /* webpackChunkName: "pages/admin/SoclialMediaAdmin/StoreisList" */))
const _2553184c = () => interopDefault(import('..\\pages\\admin\\Article\\edit\\_id.vue' /* webpackChunkName: "pages/admin/Article/edit/_id" */))
const _b67c7338 = () => interopDefault(import('..\\pages\\admin\\Charge\\_id.vue' /* webpackChunkName: "pages/admin/Charge/_id" */))
const _5d6d56c0 = () => interopDefault(import('..\\pages\\admin\\VirifiUser\\_id.vue' /* webpackChunkName: "pages/admin/VirifiUser/_id" */))
const _5c0fc41c = () => interopDefault(import('..\\pages\\auth\\Password-recovery\\_token.vue' /* webpackChunkName: "pages/auth/Password-recovery/_token" */))
const _6831a22b = () => interopDefault(import('..\\pages\\email\\verify\\_id\\_hash.vue' /* webpackChunkName: "pages/email/verify/_id/_hash" */))
const _aa03b1b2 = () => interopDefault(import('..\\pages\\blog\\_id\\index.vue' /* webpackChunkName: "pages/blog/_id/index" */))
const _7c0eb6fc = () => interopDefault(import('..\\pages\\employer\\_id.vue' /* webpackChunkName: "pages/employer/_id" */))
const _72a30528 = () => interopDefault(import('..\\pages\\employerProjects\\_id.vue' /* webpackChunkName: "pages/employerProjects/_id" */))
const _a957f420 = () => interopDefault(import('..\\pages\\portfolios\\_id\\index.vue' /* webpackChunkName: "pages/portfolios/_id/index" */))
const _03996dce = () => interopDefault(import('..\\pages\\posts\\_id\\index.vue' /* webpackChunkName: "pages/posts/_id/index" */))
const _157b779a = () => interopDefault(import('..\\pages\\profiles\\_id.vue' /* webpackChunkName: "pages/profiles/_id" */))
const _5e02cd7f = () => interopDefault(import('..\\pages\\projects\\_id\\index.vue' /* webpackChunkName: "pages/projects/_id/index" */))
const _71c57f60 = () => interopDefault(import('..\\pages\\socialMedia\\_id.vue' /* webpackChunkName: "pages/socialMedia/_id" */))
const _46127884 = () => interopDefault(import('..\\pages\\posts\\_id\\edit.vue' /* webpackChunkName: "pages/posts/_id/edit" */))
const _0568f86b = () => interopDefault(import('..\\pages\\projects\\_id\\SuggestProjects.vue' /* webpackChunkName: "pages/projects/_id/SuggestProjects" */))
const _32426b16 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/About-us",
    component: _5f0b8cab,
    name: "About-us"
  }, {
    path: "/account",
    component: _2b8182f2,
    name: "account"
  }, {
    path: "/account-setting",
    component: _5ba7ece2,
    name: "account-setting"
  }, {
    path: "/announcements",
    component: _1580cbf3,
    name: "announcements"
  }, {
    path: "/blog",
    component: _725351d3,
    name: "blog"
  }, {
    path: "/chat",
    component: _c4dabf46,
    name: "chat"
  }, {
    path: "/commercialLevel",
    component: _03e40ba5,
    name: "commercialLevel"
  }, {
    path: "/Contact-us",
    component: _65a7d110,
    name: "Contact-us"
  }, {
    path: "/createProject",
    component: _21f50e3c,
    name: "createProject"
  }, {
    path: "/cv",
    component: _4b886f22,
    name: "cv"
  }, {
    path: "/dashboard",
    component: _21ebeaeb,
    name: "dashboard"
  }, {
    path: "/defferences",
    component: _73ef83b6,
    name: "defferences"
  }, {
    path: "/Followers",
    component: _5d13daea,
    name: "Followers"
  }, {
    path: "/freelancer",
    component: _366b9512,
    name: "freelancer"
  }, {
    path: "/harvest",
    component: _21696436,
    name: "harvest"
  }, {
    path: "/increaseInventory",
    component: _3c794785,
    name: "increaseInventory"
  }, {
    path: "/inspire",
    component: _2a81f9bd,
    name: "inspire"
  }, {
    path: "/Membership-upgrade",
    component: _2b626310,
    name: "Membership-upgrade"
  }, {
    path: "/messages",
    component: _0fba572e,
    name: "messages"
  }, {
    path: "/myProject",
    component: _dd6ca7dc,
    name: "myProject"
  }, {
    path: "/password",
    component: _803af88c,
    name: "password"
  }, {
    path: "/picture",
    component: _c81518fe,
    name: "picture"
  }, {
    path: "/portfolios",
    component: _55fd996a,
    name: "portfolios"
  }, {
    path: "/posts",
    component: _01123ecc,
    name: "posts"
  }, {
    path: "/projects",
    component: _0566147b,
    name: "projects"
  }, {
    path: "/records",
    component: _47c80086,
    name: "records"
  }, {
    path: "/Rules",
    component: _12cc6ffa,
    name: "Rules"
  }, {
    path: "/skills",
    component: _d1b2d31a,
    name: "skills"
  }, {
    path: "/socialMedia",
    component: _b6913830,
    name: "socialMedia"
  }, {
    path: "/stories",
    component: _0e7d0de8,
    name: "stories"
  }, {
    path: "/wallet",
    component: _cc6bcb48,
    name: "wallet"
  }, {
    path: "/admin/Announcements",
    component: _7f584758,
    name: "admin-Announcements"
  }, {
    path: "/admin/Article",
    component: _b551f8a4,
    name: "admin-Article"
  }, {
    path: "/admin/City",
    component: _4be04f65,
    name: "admin-City"
  }, {
    path: "/admin/dashboard",
    component: _ecc140dc,
    name: "admin-dashboard"
  }, {
    path: "/admin/Disputes",
    component: _3d31d1be,
    name: "admin-Disputes"
  }, {
    path: "/admin/MemberShipUpgrade",
    component: _5119f8de,
    name: "admin-MemberShipUpgrade"
  }, {
    path: "/admin/Message",
    component: _0f7a2806,
    name: "admin-Message"
  }, {
    path: "/admin/NotificationAdmin",
    component: _621e9240,
    name: "admin-NotificationAdmin"
  }, {
    path: "/admin/ProjectsAdmin",
    component: _7364b0cf,
    name: "admin-ProjectsAdmin"
  }, {
    path: "/admin/property",
    component: _b0e32c4a,
    name: "admin-property"
  }, {
    path: "/admin/PropertySendRequest",
    component: _3485995c,
    name: "admin-PropertySendRequest"
  }, {
    path: "/admin/Records",
    component: _230daa3c,
    name: "admin-Records"
  }, {
    path: "/admin/ShowRequestWallet",
    component: _544d1cce,
    name: "admin-ShowRequestWallet"
  }, {
    path: "/admin/SkillsAdmin",
    component: _54003f17,
    name: "admin-SkillsAdmin"
  }, {
    path: "/admin/UsersAdmin",
    component: _675ab6ae,
    name: "admin-UsersAdmin"
  }, {
    path: "/auth/Complete-registration",
    component: _7df77f30,
    name: "auth-Complete-registration"
  }, {
    path: "/auth/Forget",
    component: _be8f763c,
    name: "auth-Forget"
  }, {
    path: "/auth/Log-in",
    component: _23cd327a,
    name: "auth-Log-in"
  }, {
    path: "/auth/Register",
    component: _d759f950,
    name: "auth-Register"
  }, {
    path: "/dashboard/Wallet",
    component: _08def460,
    name: "dashboard-Wallet"
  }, {
    path: "/freelancer/ListFreelancer",
    component: _745b7151,
    name: "freelancer-ListFreelancer"
  }, {
    path: "/password/Change",
    component: _0a451318,
    name: "password-Change"
  }, {
    path: "/posts/create",
    component: _48e9e572,
    name: "posts-create"
  }, {
    path: "/posts/myPost",
    component: _3fe470e2,
    name: "posts-myPost"
  }, {
    path: "/posts/save",
    component: _7dba3cf3,
    name: "posts-save"
  }, {
    path: "/stories/create",
    component: _4721f332,
    name: "stories-create"
  }, {
    path: "/admin/Article/Category",
    component: _4941061c,
    name: "admin-Article-Category"
  }, {
    path: "/admin/Article/create",
    component: _2d3dbcd0,
    name: "admin-Article-create"
  }, {
    path: "/admin/SkillsAdmin/AddCategory",
    component: _cca4fab8,
    name: "admin-SkillsAdmin-AddCategory"
  }, {
    path: "/admin/SkillsAdmin/create",
    component: _53bbee87,
    name: "admin-SkillsAdmin-create"
  }, {
    path: "/admin/SoclialMediaAdmin/CreateStory",
    component: _6d4cb2f1,
    name: "admin-SoclialMediaAdmin-CreateStory"
  }, {
    path: "/admin/SoclialMediaAdmin/posts",
    component: _42433c8b,
    name: "admin-SoclialMediaAdmin-posts"
  }, {
    path: "/admin/SoclialMediaAdmin/StoreisList",
    component: _685f62be,
    name: "admin-SoclialMediaAdmin-StoreisList"
  }, {
    path: "/admin/Article/edit/:id?",
    component: _2553184c,
    name: "admin-Article-edit-id"
  }, {
    path: "/admin/Charge/:id?",
    component: _b67c7338,
    name: "admin-Charge-id"
  }, {
    path: "/admin/VirifiUser/:id?",
    component: _5d6d56c0,
    name: "admin-VirifiUser-id"
  }, {
    path: "/auth/Password-recovery/:token?",
    component: _5c0fc41c,
    name: "auth-Password-recovery-token"
  }, {
    path: "/email/verify/:id?/:hash?",
    component: _6831a22b,
    name: "email-verify-id-hash"
  }, {
    path: "/blog/:id",
    component: _aa03b1b2,
    name: "blog-id"
  }, {
    path: "/employer/:id?",
    component: _7c0eb6fc,
    name: "employer-id"
  }, {
    path: "/employerProjects/:id?",
    component: _72a30528,
    name: "employerProjects-id"
  }, {
    path: "/portfolios/:id",
    component: _a957f420,
    name: "portfolios-id"
  }, {
    path: "/posts/:id",
    component: _03996dce,
    name: "posts-id"
  }, {
    path: "/profiles/:id?",
    component: _157b779a,
    name: "profiles-id"
  }, {
    path: "/projects/:id",
    component: _5e02cd7f,
    name: "projects-id"
  }, {
    path: "/socialMedia/:id",
    component: _71c57f60,
    name: "socialMedia-id"
  }, {
    path: "/posts/:id/edit",
    component: _46127884,
    name: "posts-id-edit"
  }, {
    path: "/projects/:id/SuggestProjects",
    component: _0568f86b,
    name: "projects-id-SuggestProjects"
  }, {
    path: "/",
    component: _32426b16,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
