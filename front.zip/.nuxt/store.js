import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const VUEX_PROPERTIES = ['state', 'getters', 'actions', 'mutations']

let store = {};

(function updateModules () {
  store = normalizeRoot(require('..\\store\\index.js'), 'store/index.js')

  // If store is an exported method = classic mode (deprecated)

  if (typeof store === 'function') {
    return console.warn('Classic mode for store/ is deprecated and will be removed in Nuxt 3.')
  }

  // Enforce store modules
  store.modules = store.modules || {}

  resolveStoreModules(require('..\\store\\account.js'), 'account.js')
  resolveStoreModules(require('..\\store\\articlesAdmin.js'), 'articlesAdmin.js')
  resolveStoreModules(require('..\\store\\blog.js'), 'blog.js')
  resolveStoreModules(require('..\\store\\categoryArticleAdmins.js'), 'categoryArticleAdmins.js')
  resolveStoreModules(require('..\\store\\chat.js'), 'chat.js')
  resolveStoreModules(require('..\\store\\employer.js'), 'employer.js')
  resolveStoreModules(require('..\\store\\freelancer.js'), 'freelancer.js')
  resolveStoreModules(require('..\\store\\portfolio.js'), 'portfolio.js')
  resolveStoreModules(require('..\\store\\project.js'), 'project.js')
  resolveStoreModules(require('..\\store\\projectsAdmin.js'), 'projectsAdmin.js')
  resolveStoreModules(require('..\\store\\propertyAdmin.js'), 'propertyAdmin.js')
  resolveStoreModules(require('..\\store\\pushe.js'), 'pushe.js')
  resolveStoreModules(require('..\\store\\skills.js'), 'skills.js')
  resolveStoreModules(require('..\\store\\skillsAdmin.js'), 'skillsAdmin.js')
  resolveStoreModules(require('..\\store\\socialMediaAdmin.js'), 'socialMediaAdmin.js')
  resolveStoreModules(require('..\\store\\socillMedia.js'), 'socillMedia.js')
  resolveStoreModules(require('..\\store\\upgrate.js'), 'upgrate.js')
  resolveStoreModules(require('..\\store\\user.js'), 'user.js')
  resolveStoreModules(require('..\\store\\userAdmin.js'), 'userAdmin.js')
  resolveStoreModules(require('..\\store\\wallet.js'), 'wallet.js')
  resolveStoreModules(require('..\\store\\walletAdmin.js'), 'walletAdmin.js')

  // If the environment supports hot reloading...

  if (process.client && module.hot) {
    // Whenever any Vuex module is updated...
    module.hot.accept([
      '..\\store\\account.js',
      '..\\store\\articlesAdmin.js',
      '..\\store\\blog.js',
      '..\\store\\categoryArticleAdmins.js',
      '..\\store\\chat.js',
      '..\\store\\employer.js',
      '..\\store\\freelancer.js',
      '..\\store\\index.js',
      '..\\store\\portfolio.js',
      '..\\store\\project.js',
      '..\\store\\projectsAdmin.js',
      '..\\store\\propertyAdmin.js',
      '..\\store\\pushe.js',
      '..\\store\\skills.js',
      '..\\store\\skillsAdmin.js',
      '..\\store\\socialMediaAdmin.js',
      '..\\store\\socillMedia.js',
      '..\\store\\upgrate.js',
      '..\\store\\user.js',
      '..\\store\\userAdmin.js',
      '..\\store\\wallet.js',
      '..\\store\\walletAdmin.js',
    ], () => {
      // Update `root.modules` with the latest definitions.
      updateModules()
      // Trigger a hot update in the store.
      window.$nuxt.$store.hotUpdate(store)
    })
  }
})()

// createStore
export const createStore = store instanceof Function ? store : () => {
  return new Vuex.Store(Object.assign({
    strict: (process.env.NODE_ENV !== 'production')
  }, store))
}

function normalizeRoot (moduleData, filePath) {
  moduleData = moduleData.default || moduleData

  if (moduleData.commit) {
    throw new Error(`[nuxt] ${filePath} should export a method that returns a Vuex instance.`)
  }

  if (typeof moduleData !== 'function') {
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData)
  }
  return normalizeModule(moduleData, filePath)
}

function normalizeModule (moduleData, filePath) {
  if (moduleData.state && typeof moduleData.state !== 'function') {
    console.warn(`'state' should be a method that returns an object in ${filePath}`)

    const state = Object.assign({}, moduleData.state)
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData, { state: () => state })
  }
  return moduleData
}

function resolveStoreModules (moduleData, filename) {
  moduleData = moduleData.default || moduleData
  // Remove store src + extension (./foo/index.js -> foo/index)
  const namespace = filename.replace(/\.(js|mjs)$/, '')
  const namespaces = namespace.split('/')
  let moduleName = namespaces[namespaces.length - 1]
  const filePath = `store/${filename}`

  moduleData = moduleName === 'state'
    ? normalizeState(moduleData, filePath)
    : normalizeModule(moduleData, filePath)

  // If src is a known Vuex property
  if (VUEX_PROPERTIES.includes(moduleName)) {
    const property = moduleName
    const propertyStoreModule = getStoreModule(store, namespaces, { isProperty: true })

    // Replace state since it's a function
    mergeProperty(propertyStoreModule, moduleData, property)
    return
  }

  // If file is foo/index.js, it should be saved as foo
  const isIndexModule = (moduleName === 'index')
  if (isIndexModule) {
    namespaces.pop()
    moduleName = namespaces[namespaces.length - 1]
  }

  const storeModule = getStoreModule(store, namespaces)

  for (const property of VUEX_PROPERTIES) {
    mergeProperty(storeModule, moduleData[property], property)
  }

  if (moduleData.namespaced === false) {
    delete storeModule.namespaced
  }
}

function normalizeState (moduleData, filePath) {
  if (typeof moduleData !== 'function') {
    console.warn(`${filePath} should export a method that returns an object`)
    const state = Object.assign({}, moduleData)
    return () => state
  }
  return normalizeModule(moduleData, filePath)
}

function getStoreModule (storeModule, namespaces, { isProperty = false } = {}) {
  // If ./mutations.js
  if (!namespaces.length || (isProperty && namespaces.length === 1)) {
    return storeModule
  }

  const namespace = namespaces.shift()

  storeModule.modules[namespace] = storeModule.modules[namespace] || {}
  storeModule.modules[namespace].namespaced = true
  storeModule.modules[namespace].modules = storeModule.modules[namespace].modules || {}

  return getStoreModule(storeModule.modules[namespace], namespaces, { isProperty })
}

function mergeProperty (storeModule, moduleData, property) {
  if (!moduleData) {
    return
  }

  if (property === 'state') {
    storeModule.state = moduleData || storeModule.state
  } else {
    storeModule[property] = Object.assign({}, storeModule[property], moduleData)
  }
}
