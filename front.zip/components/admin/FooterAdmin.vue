<template>

</template>

<script>
export default {
  name: 'FooterAdmin'
}
</script>

<style scoped>

</style>
