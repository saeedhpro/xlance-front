<template>
  <div class="container ">
<div class="my-10 flex flex-wrap justify-center">
  <div class="sm:w-1/4 w-full sm:m-0 m-5 mx-10 text-center">
    <img src="/images/us_dollar_soon.png" class="m-auto"/>
    <h2 class="my-3 text-black fa-fo ka-font  text-2xl font-black	">قیمت گذاری هوشمند</h2>
    <p class="w-32 mx-auto text-black text-sm ir-medium " style="opacity: 0.75; font-size: 13px">قیمت‌گذاری خودکار و هوشمند پروژه‌ها</p>
  </div>
  <div class="sm:w-1/4 w-full sm:m-0 m-5 mx-10 text-center">
    <img src="/images/trophy.png" class="m-auto"/>
    <h2 class="my-3 text-black fa-fo ka-font text-2xl font-black	">برترین فریلنسرها</h2>
    <p class="w-32 mx-auto text-black text-sm ir-medium " style="opacity: 0.75; font-size: 13px">فریلنسرهای حرفه‌ای و کاربلد از سراسر کشور</p>
  </div>
  <div class="sm:w-1/4 w-full sm:m-0 m-5 mx-10 text-center">
    <img src="/images/safe.png" class="m-auto"/>
    <h2 class="my-3 text-black fa-fo ka-font text-2xl font-black	">سیستم پرداخت امن</h2>
    <p class="w-32 mx-auto text-black text-sm ir-medium " style="opacity: 0.75; font-size: 13px">تضمین امنیت پرداخت‌ها در پروژه‌ها</p>
  </div>
  <div class="sm:w-1/4 w-full sm:m-0 m-5 mx-10 text-center">
    <img src="/images/wi-fi.png" class="m-auto"/>
    <h2 class="my-3 text-black fa-fo ka-font text-2xl font-black	">کاملا آنلاین و اینترنتی</h2>
    <p class="w-32 mx-auto text-black text-sm ir-medium " style="opacity: 0.75; font-size: 13px">همه فرآیندها به صورت آنلاین و اینترنتی</p>
  </div>
</div>
  </div>
</template>
<script>
    export default {
        name: "Advantages"
    }
</script>
<style>
  .fa-fo{
    text-align: center;
    letter-spacing: 0px;
    color: #212121;
  }
</style>
