<template>
    <div>
      <nuxt-link to="/createProject" class=" p-1 h-8 w-32  text-purple-600  justify-center rounded-lg border border-purple-600 items-center flex">
        <i class="fal fa-plus-square"></i>
        <span class="mx-3 text-sm">ایجاد پروژه</span>
      </nuxt-link>
    </div>
</template>
<script>
    export default {
        name: "CreateProject"
    }
</script>
