<template>
<div>
  <div class="flex">
  <slot name="hea1"></slot>
  <slot name="hea2"></slot>
  <slot name="hea3"></slot>
  </div>
</div>
</template>
<script>
    export default {
        name: "TabSelect"
    }
</script>
