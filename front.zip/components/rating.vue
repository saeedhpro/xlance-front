<template>

</template>

<script>
    export default {
        name: "rating"
    }
</script>

<style scoped>

</style>
