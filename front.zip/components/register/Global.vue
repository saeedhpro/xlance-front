<template>
    <div>
      <slot name="head" class="text-lg text-black">ورود به سایت</slot>
      <img src="/images/art5.png" class="my-3 mx-auto"/>
    </div>
</template>

<script>
    export default {
        name: "Global"
    }
</script>

<style scoped>

</style>
