<template>
      <div class="my-10 bg-gray-100 min-h-screen">
      <nuxt/>
      </div>
</template>

<script>
    export default {
        name: "createPro",
    }
</script>
