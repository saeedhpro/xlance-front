<template>
<div>
  <nuxt/>
</div>
</template>
<script>

export default {
    name:'empty',
}
</script>
