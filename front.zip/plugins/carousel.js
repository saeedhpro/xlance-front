
import Vue from 'vue'
import OwlCarousel from 'sh-v-owl-carousel'

Vue.component('carousel', OwlCarousel)
