import Vue from 'vue';
const vueAwesomeCountdown = require('vue-awesome-countdown').default;

Vue.use(vueAwesomeCountdown, 'vac');
