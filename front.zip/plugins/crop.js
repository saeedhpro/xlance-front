import Vue from 'vue'
import VueCrop from 'vue-crop-simple';
import 'vue-crop-simple/dist/vue-crop-simple.css';
Vue.use(VueCrop);
