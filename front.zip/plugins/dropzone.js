import Vue from 'vue'

import Dropzone from 'nuxt-dropzone'
import 'nuxt-dropzone/dropzone.css'

Vue.use(Dropzone)
