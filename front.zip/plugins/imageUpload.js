import Vue from 'vue'
import 'babel-polyfill'; // es6 shim
import myUpload from 'vue-image-crop-upload/upload-2';
Vue.use(myUpload);
