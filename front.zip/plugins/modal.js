// plugins/vue-js-modal.js
import Vue from 'vue'
import VModal from 'sh-vue-js-modal/dist/ssr.nocss'

import 'sh-vue-js-modal/dist/styles.css'

Vue.use(VModal, {  })

/*
export default function(_, inject) {
  inject('modal', VModal)
}
*/
