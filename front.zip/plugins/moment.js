export default {
  buildModules: [
    'nuxt-moment-jalaali'
  ],
  moment: {
    plugins: [
      'moment-strftime',
      'moment-fquarter'
    ]
  }
}
