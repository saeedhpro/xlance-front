import Vue from 'vue'
Vue.component('pagination', require('laravel-vue-pagination'));
