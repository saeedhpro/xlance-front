import vuePersianFilters from "vue-persian-filters"
import Vue from "vue"

Vue.use(vuePersianFilters);
