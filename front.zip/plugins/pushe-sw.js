importScripts("https://static.pushe.co/pusheweb-sw.js");
var Pushe = require('pushe-webpush');
Pushe.init("3cff366b246cb76842103e3982f8d8c5f6641b48");
Pushe.subscribe();
