import Vue from 'vue'
import Button from 'vue-js-toggle-button'

Vue.use(Button)
