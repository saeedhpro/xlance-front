import Vue from 'vue'
import TinyMCE from 'tinymce-vue-2'

Vue.component('tiny-mce', TinyMCE)
