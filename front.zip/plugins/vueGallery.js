
import Vue from 'vue'
import VueGallerySlideshow from 'vue-gallery-slideshow'
Vue.use(VueGallerySlideshow);
